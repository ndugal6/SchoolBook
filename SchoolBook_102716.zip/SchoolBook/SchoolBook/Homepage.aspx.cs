﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SchoolBook
{
    public partial class Homepage : System.Web.UI.Page
    {
        string connstr = @"Data Source=localhost; Database=school_book_db; User Id=root; Password=password1";
        protected void Page_Load(object sender, EventArgs e)
        {
            string fullname;
            string Email = Request.QueryString["Parameter"].ToString();
            MySqlConnection conn = new MySqlConnection(connstr);

            try
            {
                conn.Open();
                string cmd = "SELECT FullName FROM useraccounts WHERE Email = '" + Email + "';";
                MySqlCommand sqlcmd = new MySqlCommand(cmd, conn);
                fullname = (string)sqlcmd.ExecuteScalar();
                Fname.InnerHtml = fullname;
            }
            catch (MySqlException ex)
            {

            }

            conn.Close();
        }
    }
}