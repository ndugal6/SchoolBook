﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace SchoolBook
{
    public partial class Default : System.Web.UI.Page
    {
        string connstr = @"Data Source=localhost; Database=school_book_db; User Id=root; Password=password1";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void login_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection(connstr);

            try
            {
                conn.Open();
                string cmd = "SELECT UserName FROM useraccount WHERE idUserAccount = '101'";
                MySqlCommand sqlcmd = new MySqlCommand(cmd, conn);
                string res = Convert.ToString(sqlcmd.ExecuteScalar());
                loginstatuslbl.InnerHtml = "Sucessfully Connected to database as user: " + res;

            }
            catch (MySqlException ex)
            {
                loginstatuslbl.InnerHtml = ex.ToString();
            }
        }



        protected void Reg_Click(object sender, EventArgs e)
        {
            string Email = email.Value;
            string password = formpassword.Value;
            string cfmemail = regcfmemail.Value;
            string cfmpassword = regcfmpassword.Value;
            string DOB = DobInput.Value;
            string fullname = regFullName.Value;
            string gender = "empty";
            if (regMale.Value == "Male")
                gender = "male";
            else if (regFemale.Value == "Female")
                gender = "female";
            string uni = regUni.Value;

            Response.Write(Email + " " + password + " " + cfmemail + " " + cfmpassword + " " +DOB + " " +fullname + " " + gender + " " + uni);
        }


    }
}