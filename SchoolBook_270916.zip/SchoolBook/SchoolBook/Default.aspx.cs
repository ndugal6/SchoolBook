﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace SchoolBook
{
    public partial class Default : System.Web.UI.Page
    {
        string connstr = @"Data Source=localhost; Database=school_book_db; User Id=root; Password=password1";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void login_Click(object sender, EventArgs e)
        {
            string Email = email.Value;
            string password = formpassword.Value;
            MySqlConnection conn = new MySqlConnection(connstr);

            try
            {
                conn.Open();
                string cmd = "SELECT * FROM useraccounts WHERE Email = '" + Email +"' and Password = '" + password + "';";
                MySqlCommand sqlcmd = new MySqlCommand(cmd, conn);

                if (sqlcmd.ExecuteReader().Read())
                {
                    loginstatuslbl.InnerHtml = "Logged in sucessfully";
                    Response.Redirect("Homepage.aspx");
                }
                else
                    loginstatuslbl.InnerHtml = "incorrect Userid / Password!";

            }
            catch (MySqlException ex)
            {
                loginstatuslbl.InnerHtml = ex.ToString();
            }
        }



        protected void Reg_Click(object sender, EventArgs e)
        {
            string Email = email.Value;
            string password = formpassword.Value;
            string cfmemail = regcfmemail.Value;
            string cfmpassword = regcfmpassword.Value;
            string DOB = DobInput.Value;
            string fullname = regFullName.Value;
            string gender = "empty";
            if (regMale.Value == "Male")
                gender = "M";
            else if (regFemale.Value == "Female")
                gender = "F";
            string uni = regUni.Value;

            MySqlConnection conn = new MySqlConnection(connstr);

            try
            {
                conn.Open();
                string cmd = "INSERT INTO useraccounts (Email,Password,UniversityID,Gender,DOB) Values ('" + Email + "','" + password + "','500000000','" + gender + "','" + DOB +"');" ;
                MySqlCommand sqlcmd = new MySqlCommand(cmd, conn);
                sqlcmd.ExecuteNonQuery();
                loginstatuslbl.InnerHtml = "Sucessfully Registered!";

            }
            catch (MySqlException ex)
            {
                loginstatuslbl.InnerHtml = ex.ToString();
            }

        }


    }
}